package com.shop.constant;

public enum OrderStatus {
        ORDER, CANCLE
}

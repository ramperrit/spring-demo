package com.shop.exception;

public class OutOfStackException extends RuntimeException{
    public OutOfStackException(String message){
        super(message);
    }
}
